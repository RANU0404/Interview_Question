package stepdefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import io.cucumber.java.en.*;
import static org.junit.Assert.*;

public class LongestSubstringSteps {

    WebDriver driver;
    String input = "abcabcbb";
    String expectedOutput = "abc"; 
    String actualOutput;

    @Given("Chrome browser is launched")
    public void chrome_browser_is_launched() {
        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");
        driver = new ChromeDriver();
    }

    @And("user navigates to {string}")
    public void user_navigates_to(String url) {
        driver.get(url);
    }

    @When("user enters input string {string} into the input box")
    public void user_enters_input_string_into_input_box(String inputString) {
        this.input = inputString;
        WebElement inputBox = driver.findElement(By.id("inputString")); 
        inputBox.sendKeys(input);
    }

    @When("clicks the submit button")
    public void clicks_submit_button() {
        WebElement submitButton = driver.findElement(By.id("submitBtn")); 
        submitButton.click();
    }

    @Then("output string should be displayed")
    public void output_string_should_be_displayed() {
        WebElement output = driver.findElement(By.id("outputString"));
        actualOutput = output.getText();
        assertNotNull("Output string is not displayed", actualOutput);
    }

    @Then("the displayed string should be the longest substring without repeating characters")
    public void validate_longest_substring() {
        assertEquals("Longest substring doesn't match", expectedOutput, actualOutput);
        driver.quit();
    }
}
